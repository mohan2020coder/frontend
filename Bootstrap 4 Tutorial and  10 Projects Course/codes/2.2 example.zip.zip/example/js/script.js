$(document).ready(function () {
    // ripples
    $("#header, .info").ripples({
        resolution: 512,
        dropRadius: 20,
        perturbance: 0.04,
        imageUrl: null
    });


    


});
